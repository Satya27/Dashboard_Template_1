﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.TransparencyKey = this.BackColor;
            SmoothRoundedPanel(panel1, 75, panel1.BackColor);
            SmoothRoundedPanel(panel2, 30, panel2.BackColor);
            SmoothRoundedPanel(panel3, 30, panel3.BackColor);

            SmoothRoundedPanel(panel4, 15, panel4.BackColor);
            SmoothRoundedPanel(panel5, 15, panel5.BackColor);
            SmoothRoundedPanel(panel6, 15, panel6.BackColor);

            SmoothRoundedPanel(panel7, 10, panel7.BackColor);
            SmoothRoundedPanel(panel8, 10, panel8.BackColor);
            SmoothRoundedPanel(panel9, 15, panel9.BackColor);

            SmoothRoundedPanel(panel11, 15, panel11.BackColor);
            SmoothRoundedPanel(panel12, 15, panel12.BackColor);


        }

        private void SmoothRoundedPanel(Panel panel, int cornerRadius, Color baseColor)
        {
            panel.BackColor = Color.Transparent;

            // Override WndProc untuk menggambar latar belakang panel dengan efek sudut yang terbulat yang lebih halus
            panel.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                Rectangle rect = new Rectangle(0, 0, panel.Width, panel.Height);

                using (GraphicsPath path = new GraphicsPath())
                {
                    path.AddArc(rect.X, rect.Y, cornerRadius, cornerRadius, 180, 90);
                    path.AddArc(rect.Width - cornerRadius, rect.Y, cornerRadius, cornerRadius, 270, 90);
                    path.AddArc(rect.Width - cornerRadius, rect.Height - cornerRadius, cornerRadius, cornerRadius, 0, 90);
                    path.AddArc(rect.X, rect.Height - cornerRadius, cornerRadius, cornerRadius, 90, 90);
                    path.CloseAllFigures();

                    using (LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(255, baseColor), Color.FromArgb(255, baseColor), LinearGradientMode.Vertical))
                    {
                        e.Graphics.FillPath(brush, path);
                    }
                }
            };
        }


    }
}
